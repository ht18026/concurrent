/* Copyright (C) 2017 Daniel Page <csdsp@bristol.ac.uk>
 *
 * Use of this source code is restricted per the CC BY-NC-ND license, a copy of
 * which can be found via http://creativecommons.org (and should be included as
 * LICENSE.txt within the associated archive or repository).
 */

#include "hilevel.h"



pcb_t procTab[ MAX_PROCS ]; pcb_t* executing = NULL;

void dispatch( ctx_t* ctx, pcb_t* prev, pcb_t* next ) {
  char prev_pid = '?', next_pid = '?';

  if( NULL != prev ) {
    memcpy( &prev->ctx, ctx, sizeof( ctx_t ) ); // preserve execution context of P_{prev}
    prev_pid = '0' + prev->pid;
  }
  if( NULL != next ) {
    memcpy( ctx, &next->ctx, sizeof( ctx_t ) ); // restore  execution context of P_{next}
    next_pid = '0' + next->pid;
  }

    PL011_putc( UART0, '[',      true );
    PL011_putc( UART0, prev_pid, true );
    PL011_putc( UART0, '-',      true );
    PL011_putc( UART0, '>',      true );
    PL011_putc( UART0, next_pid, true );
    PL011_putc( UART0, ']',      true );

    executing = next;                           // update   executing process to P_{next}

  return;
}

void schedule( ctx_t* ctx ) {
  int maxSum = -1;
  int former = 0;
  int next = 0;
  for( int i = 0; i < MAX_PROCS; i++ ) {
    if(procTab[ i ].status == STATUS_CREATED||procTab[ i ].status == STATUS_READY ){      //add age to all using processes
      procTab[ i ].age += 1;
      if(procTab[ i ].age + procTab[ i ].priority > maxSum ){                             //dynamic priority-based
        next = i;
        maxSum = procTab[ i ].age + procTab[ i ].priority;
      }
    }


  }

    procTab[ executing->pid ].age = 0;
    procTab[ executing->pid ].status = STATUS_READY;
    dispatch( ctx, &procTab[ executing->pid ], &procTab[ next ] );
    procTab[  next ].status = STATUS_EXECUTING;






  return;
}

extern void main_console();
// extern uint32_t tos_console;
extern void     main_P1();
extern uint32_t tos_P0;
extern void     main_P2();
extern void     main_P3();
extern void     main_P4();
extern void     main_P5();
extern void     main_Ph();





void hilevel_handler_rst( ctx_t* ctx              ) {
  /* Invalidate all entries in the process table, so it's clear they are not
   * representing valid (i.e., active) processes.
   */
   TIMER0->Timer1Load  = 0x00100000; // select period = 2^20 ticks ~= 1 sec
   TIMER0->Timer1Ctrl  = 0x00000002; // select 32-bit   timer
   TIMER0->Timer1Ctrl |= 0x00000040; // select periodic timer
   TIMER0->Timer1Ctrl |= 0x00000020; // enable          timer interrupt
   TIMER0->Timer1Ctrl |= 0x00000080; // enable          timer

   GICC0->PMR          = 0x000000F0; // unmask all            interrupts
   GICD0->ISENABLER1  |= 0x00000010; // enable timer          interrupt
   GICC0->CTLR         = 0x00000001; // enable GIC interface
   GICD0->CTLR         = 0x00000001; // enable GIC distributor


  for( int i = 0; i < MAX_PROCS; i++ ) {
    procTab[ i ].status = STATUS_INVALID;
  }

  /* Automatically execute the user programs P1 and P2 by setting the fields
   * in two associated PCBs.  Note in each case that
   *
   * - the CPSR value of 0x50 means the processor is switched into USR mode,
   *   with IRQ interrupts enabled, and
   * - the PC and SP values match the entry point and top of stack.
   */

  memset( &procTab[ 0 ], 0, sizeof( pcb_t ) ); // initialise 0-th PCB = P_1
  procTab[ 0 ].pid      = 0;
  procTab[ 0 ].status   = STATUS_READY;
  procTab[ 0 ].tos      = ( uint32_t )( &tos_P0 );
  procTab[ 0 ].ctx.cpsr = 0x50;
  procTab[ 0 ].ctx.pc   = ( uint32_t )( &main_console );
  procTab[ 0 ].ctx.sp   = procTab[ 0 ].tos;
  procTab[ 0 ].priority = 1;
  procTab[ 0 ].age = 0;

 for(int i = 1; i<=24; i++){
  // uint32_t s = tos_P0;
  // s = s + 0x00001000 * i;
  memset( &procTab[ i ], 0, sizeof( pcb_t ) );
  procTab[ i ].pid      = i;
  procTab[ i ].status   = STATUS_INVALID;
  procTab[ i ].tos      = ( uint32_t )( &tos_P0 + 0x00001000 * i );

  procTab[ i ].ctx.cpsr = 0x50;

  procTab[ i ].ctx.sp   = procTab[ i ].tos;
  procTab[ i ].priority = 0 ;
  procTab[ i ].age = 0 ;
}





  /* Once the PCBs are initialised, we arbitrarily select the 0-th PCB to be
   * executed: there is no need to preserve the execution context, since it
   * is invalid on reset (i.e., no process was previously executing).
   */

  dispatch( ctx, NULL, &procTab[ 0 ] );
  int_enable_irq();

  return;
}

void hilevel_handler_svc( ctx_t* ctx, uint32_t id ) {
  /* Based on the identifier (i.e., the immediate operand) extracted from the
   * svc instruction,
   *
   * - read  the arguments from preserved usr mode registers,
   * - perform whatever is appropriate for this system call, then
   * - write any return value back to preserved usr mode registers.
   */

  switch( id ) {
    case 0x00 : { // 0x00 => yield()


      break;
    }

    case 0x01 : { // 0x01 => write( fd, x, n )
      int   fd = ( int   )( ctx->gpr[ 0 ] );
      char*  x = ( char* )( ctx->gpr[ 1 ] );
      int    n = ( int   )( ctx->gpr[ 2 ] );

      for( int i = 0; i < n; i++ ) {
        PL011_putc( UART0, *x++, true );
      }

      ctx->gpr[ 0 ] = n;

      break;
    }
    case 0x03 :{                       //fork
      procTab[executing -> pid].priority -= 1;  //parent priority -1

      int x = 0;
      for(int i = 0; i< MAX_PROCS;i++) {

        if (procTab[ i ].status == STATUS_INVALID||procTab[ i ].status == STATUS_TERMINATED){  //find an available slot to insert

          x = i;
          break;
        }
      }

      memcpy(&procTab[ x ].ctx, ctx, sizeof(ctx_t));   //copy stack to child

      procTab[ x ].status = STATUS_CREATED;            //set status to child
      // copy the stack pointer to child
      uint32_t spo = (uint32_t) executing ->tos - ctx -> sp; //corresponding part for child process
      procTab[ x ].ctx.sp = procTab[ x ].tos - spo;
      memcpy((void *)procTab[x].ctx.sp,(void *)ctx -> sp, spo);

      procTab[x].ctx.gpr[0] = 0;                  //setting child return to zero
      ctx -> gpr[0] = procTab[x].pid;               //setting parent return to pid of child
      PL011_putc( UART0, 'F',      true );             //used to clearly show the times of fork called
break;





    }
    case 0x04 :{                       //exit

      procTab[executing ->pid].age = 0;
      procTab[executing ->pid].status = STATUS_TERMINATED;
      // dispatch( ctx, &procTab[ executing->pid ], &procTab[ 0 ] );
      schedule( ctx );
      PL011_putc( UART0, 'E',      true );
      PL011_putc( UART0, 'X', true );
      PL011_putc( UART0, 'I', true );
      PL011_putc( UART0, 'T', true );





      break;
    }
    case 0x05 :{                       //exec
      ctx -> sp= procTab[ executing ->pid].tos;   //reset sp
      ctx -> pc = (uint32_t) ctx ->gpr[0];        //getting returned address generated by console
      PL011_putc( UART0, 'E',      true );
      PL011_putc( UART0, 'x', true );
      PL011_putc( UART0, 'e', true );
      PL011_putc( UART0, 'c', true );
      break;
    }
    case 0x06:{                     //kill
    int toKill = (uint32_t) ctx ->gpr[0];
    procTab[ toKill ].status = STATUS_TERMINATED;
    procTab[ toKill ].age = 0;
    if (executing->pid == toKill){
      schedule( ctx );
    }


    }



    default   : { // 0x?? => unknown/unsupported
      break;
    }
  }

  return;
}



void hilevel_handler_irq(ctx_t* ctx) {
  // Step 2: read  the interrupt identifier so we know the source.

  uint32_t id = GICC0->IAR;

  // Step 4: handle the interrupt, then clear (or reset) the source.

  if( id == GIC_SOURCE_TIMER0 ) {
    schedule( ctx );

    PL011_putc( UART0, 'T', true );
    TIMER0->Timer1IntClr = 0x01;
  }

  // Step 5: write the interrupt identifier to signal we're done.

  GICC0->EOIR = id;

  return;
}
