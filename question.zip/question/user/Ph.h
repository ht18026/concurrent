//
#ifndef __Ph_H
#define __Ph_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
// #include <pthread.h> // pthread_create(), pthread_join()
// #include <semaphore.h>

// #include <unistd.h>


#include <string.h>
#include "libc.h"
#include "PL011.h"
// #include "chop.c"




#endif
