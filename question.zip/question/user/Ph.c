#include "Ph.h"
// #include <sys/types.h>
// #include <sys/stat.h>

int chop[17] = {1 ,1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}; // 16 chopsticks and 1 lock


int check(int e){
    if(e == 16) return 0;             //ensure 15's next is 0
    return e;
}
// void sleep(){
//   for(int p = -999999;p++;p<=999999999){
//     p=p-0.999999;
//   }
// }

void main_Ph (){
    write( STDOUT_FILENO, "parent running\n", 15);

    //create 16 philosophers
    for(int i = 0; i<16; i++){

        if(fork() == 0){               //child context begins



            char c[2];
            itoa(c, i);   // convert for printing

            write( STDOUT_FILENO, "Philosopher ", 12);
            write( STDOUT_FILENO, c, 2);
            write( STDOUT_FILENO, " initialised\n", 13 );



            while(1){   // loop forever



                write( STDOUT_FILENO, "Philosopher ", 12);
                write( STDOUT_FILENO, c, 2);
                write( STDOUT_FILENO, " is waiting\n", 12 );
                sleep();


                sem_wait(&chop[16]);              //wait for chopstick
                write( STDOUT_FILENO, "Philosopher ", 12);
                write( STDOUT_FILENO, c, 2);
                write( STDOUT_FILENO, " has waited\n", 12 );

                int right = check(i +1);


                if(chop[i] == 1 && chop[right] == 1){     //pick up chopsticks when both available
                    sem_wait(&chop[right]);
                    sem_wait(&chop[i]);                      //wait for corresponding chopsticks
                    sem_post(&chop[16]);                      //post chopstick lock
                    write( STDOUT_FILENO, "Philosopher ",12);
                    write( STDOUT_FILENO, c, 2);
                    write( STDOUT_FILENO, " picking chopsticks\n", 20 );
                }
                else{                                  //keep waiting else
                    sem_post(&chop[16]);
                    write( STDOUT_FILENO, "Philosopher ", 12);
                    write( STDOUT_FILENO, c, 2);
                    write( STDOUT_FILENO, " still thinking\n", 16 );

                    // sleep();

                    continue;                            // skip to above
                }


                write( STDOUT_FILENO, "Philosopher ", 12);
                write( STDOUT_FILENO, c, 2);
                write( STDOUT_FILENO, " began eating\n", 14 );
                sleep();
                write( STDOUT_FILENO, "Philosopher ", 12);
                write( STDOUT_FILENO, c, 2);
                write( STDOUT_FILENO, " finished eating\n", 17 );


                sem_wait(&chop[16]);           //access to CR
                sem_post(&chop[right]);        //release lock
                sem_post(&chop[i] );
                sem_post(&chop[16] );

                write( STDOUT_FILENO, "Philosopher ", 12);
                write( STDOUT_FILENO, c, 2);
                write( STDOUT_FILENO, " put back chopsticks\n", 21 );
            }
        }
    }
    write( STDOUT_FILENO, "Parent leaving\n", 15);
    exit( EXIT_SUCCESS );
}
